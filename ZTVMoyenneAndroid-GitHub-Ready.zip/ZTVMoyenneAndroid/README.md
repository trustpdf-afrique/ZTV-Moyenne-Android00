# ZTV Moyenne — Android

Projet Android professionnel basé sur l'application Web `index.html` fournie.

## Identité définitive
- Nom : **ZTV Moyenne**
- Application ID / package : **com.ztvmoyenne.app**
- Version : **1.0.0**
- Version code : **10000**
- Orientation : portrait
- SDK cible : 35
- SDK minimum : 23

## Intégration
Le fichier `app/src/main/assets/index.html` est embarqué dans l'application. Le WebView active JavaScript et le stockage DOM afin de préserver le fonctionnement de l'application existante, notamment les données locales et la sélection de photos.

## Icône et écran de démarrage
L'identité visuelle ZTV Moyenne fournie dans l'application a été réutilisée pour :
- icône adaptative Android ;
- icône ronde ;
- écran de démarrage ;
- aperçu de lancement avant affichage du WebView.

## Signature Release
La configuration Gradle accepte un fichier `keystore.properties` local. Pour créer votre clé de signature :

```bash
./signing/GENERATE_RELEASE_KEYSTORE.sh
```

Puis ouvrez le projet dans Android Studio et lancez :

```text
Build > Generate Signed Bundle / APK > APK > release
```

**Important :** la clé de signature doit être conservée de manière privée et sauvegardée. Elle sera indispensable pour les futures mises à jour publiées avec le même package.

## Compilation
Android Studio avec Android SDK 35 est recommandé. Le projet a été préparé pour une compilation Release avec le package définitif `com.ztvmoyenne.app`.


## Identité visuelle finale

Le logo fourni par le propriétaire du projet a été intégré comme :
- icône principale Android ;
- icône ronde ;
- icône adaptative Android 8+ ;
- visuel de l'écran de démarrage Android 12+ et des versions antérieures.

Les coins noirs de l'image source ont été rendus transparents afin d'éviter un carré noir autour du logo dans le lanceur.

## Identité Android définitive

- Nom affiché : **ZTV Moyenne**
- Application ID / package : **com.ztvmoyenne.app**
- Version Name : **1.0.0**
- Version Code : **10000**
- Min SDK : **23**
- Target SDK : **35**
- Orientation : **portrait**

## Signature Release

La signature Release est préparée via `keystore.properties`. Ne jamais publier le keystore ni les mots de passe dans un dépôt public.

## Compilation automatique avec GitHub

Le dossier `.github/workflows/` contient deux workflows :
- `build-apk.yml` : produit automatiquement un APK Debug installable et le publie comme Artifact GitHub ;
- `build-release.yml` : produit un APK Release signé à partir des Secrets GitHub de signature.

Voir `GITHUB_APK.md` pour la procédure pas à pas.
