# Obtenir l'APK ZTV Moyenne directement avec GitHub

## Méthode la plus simple : APK installable de test

1. Créez un dépôt GitHub, par exemple `ZTV-Moyenne-Android`.
2. Décompressez ce projet et envoyez **tout le contenu du dossier `ZTVMoyenneAndroid`** dans le dépôt.
3. Dans GitHub, ouvrez l'onglet **Actions**.
4. Sélectionnez **Construire APK ZTV Moyenne**.
5. Appuyez sur **Run workflow**.
6. Attendez la fin du travail (le premier build peut prendre quelques minutes).
7. Ouvrez l'exécution terminée.
8. Dans **Artifacts**, téléchargez **ZTV-Moyenne-APK-Debug**.
9. Décompressez l'artefact : vous trouverez `app-debug.apk`.
10. Installez ce fichier sur votre téléphone Android.

Le workflow est déjà configuré pour installer Java 17 et Gradle 8.10 sur le serveur GitHub ; vous n'avez donc pas besoin d'installer Android Studio sur votre téléphone ou votre ordinateur pour ce build.

## Pour un APK Release signé

Le workflow **Construire APK Release ZTV Moyenne** est également fourni. Il nécessite un keystore que vous devez conserver vous-même.

Ajoutez dans le dépôt GitHub, dans **Settings > Secrets and variables > Actions**, les secrets suivants :

- `ZTV_KEYSTORE_B64` : contenu Base64 de votre fichier `.jks`
- `ZTV_STORE_PASSWORD` : mot de passe du keystore
- `ZTV_KEY_ALIAS` : alias de la clé
- `ZTV_KEY_PASSWORD` : mot de passe de la clé

Puis lancez manuellement **Construire APK Release ZTV Moyenne** depuis l'onglet Actions. L'APK apparaîtra dans **Artifacts** sous `ZTV-Moyenne-APK-Release`.

### Important

Ne mettez jamais le fichier `.jks`, les mots de passe ou le fichier `keystore.properties` dans le dépôt GitHub. Le workflow les reconstruit temporairement à partir des Secrets GitHub.

Conservez une copie de votre keystore dans un endroit sûr : la même clé sera nécessaire pour publier les futures mises à jour de l'application `com.ztvmoyenne.app`.
