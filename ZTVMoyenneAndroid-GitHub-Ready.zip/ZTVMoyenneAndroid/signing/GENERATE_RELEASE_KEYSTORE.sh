#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

KEYSTORE="ztv-moyenne-release.jks"
if [[ -f "$KEYSTORE" ]]; then
  echo "Le keystore $KEYSTORE existe déjà. Aucun remplacement."
  exit 0
fi

read -r -p "Mot de passe du keystore : " STORE_PASSWORD
echo
read -r -p "Mot de passe de la clé (Entrée = même mot de passe) : " KEY_PASSWORD
echo
KEY_PASSWORD="${KEY_PASSWORD:-$STORE_PASSWORD}"

keytool -genkeypair -v   -keystore "$KEYSTORE"   -alias ztv-moyenne   -keyalg RSA   -keysize 4096   -validity 10000   -storepass "$STORE_PASSWORD"   -keypass "$KEY_PASSWORD"   -dname "CN=ZTV Moyenne, OU=Mobile, O=ZTV Moyenne, L=Abidjan, ST=Abidjan, C=CI"

cat > keystore.properties <<EOF
storeFile=$KEYSTORE
storePassword=$STORE_PASSWORD
keyAlias=ztv-moyenne
keyPassword=$KEY_PASSWORD
EOF

echo "Keystore créé : $KEYSTORE"
echo "Configuration créée : keystore.properties"
echo "CONSERVEZ CES DEUX FICHIERS EN LIEU SÛR."
