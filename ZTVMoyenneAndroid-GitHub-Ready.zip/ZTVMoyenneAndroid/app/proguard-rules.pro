# ZTV Moyenne: no custom ProGuard rules required.
